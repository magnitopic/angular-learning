<?php

include "rb-mysql.php";
//R::setup('mysql:host=sql210.byethost3.com;dbname=b3_35532089_tienda_angular_ejemplo','b3_35532089','2bw765yd');
R::setup("mysql:host=localhost;dbname=db_entrega","root","");

