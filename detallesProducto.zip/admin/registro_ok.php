<?php

include("menu.html");

echo("registro realizado correctamente");