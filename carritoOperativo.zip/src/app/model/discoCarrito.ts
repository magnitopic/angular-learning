import { Disco } from './disco';

export class DiscoCarrito {
	disco?: Disco;
	cantidad?: number;
}
