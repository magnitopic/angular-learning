export class Disco {
	id?: number;
	nombre?: string;
	artista?: string;
	genero?: string;
	fecha?: string;
	precio?: number;
}
